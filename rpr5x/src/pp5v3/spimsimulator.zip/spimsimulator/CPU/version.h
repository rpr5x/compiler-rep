#define SPIM_VERSION "Version 9.1.8 of December 9, 2012"
